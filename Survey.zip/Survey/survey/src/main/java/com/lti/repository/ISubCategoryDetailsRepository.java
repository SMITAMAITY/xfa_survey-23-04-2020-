package com.lti.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.models.SubCategoryDetails;

public interface ISubCategoryDetailsRepository extends CrudRepository<SubCategoryDetails, Integer>  {

}
