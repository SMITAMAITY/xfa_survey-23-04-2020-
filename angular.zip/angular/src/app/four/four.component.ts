import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-four',
  templateUrl: './four.component.html',
  styleUrls: ['./four.component.css']
})
export class FourComponent implements OnInit {

  url:string= "http://localhost:8080/QuestionDetails/Collaboration";
  a:any;
c:any;
i:any;
j:any;
k:any;
a1:any;
a2:any;
a3:any;
a4:any;
a5:any;

z11;z12;z13;z14;
z21;z22;z23;
z31;
  result:any;

  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.http.get(this.url).subscribe(data=>{
      
      
      this.result = data;
      console.log(this.result);
      
      this.result=data;
      console.log(this.result);
      // this.a = this.result[0].subCategoryDetails[0];
     // this.c = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z11 = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z12 = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z13 = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z14 = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z21 = this.result[0].subCategoryDetails[1].questionDetails[0];
      this.z22 = this.result[0].subCategoryDetails[1].questionDetails[0];
      this.z23= this.result[0].subCategoryDetails[1].questionDetails[0];
      this.z31= this.result[0].subCategoryDetails[2].questionDetails[0];
   
    

        // for(this.j=0;this.j<5;this.j++)
        // {
        //   this.a = this.result[0].subCategoryDetails[this.j];
        // }
        

        // for(let i=0;i<5;i++)
        // {
          this.a1 = this.result[0].subCategoryDetails[0];
          this.a2= this.result[0].subCategoryDetails[1];
          this.a3= this.result[0].subCategoryDetails[2];
          
    
        // }
   
      console.log(this.a);
      // console.log(this.result.CategoryDetails.SubCategoryDetails);
      // console.log(this.result.categoryDetails.subCategoryDetails.questionDetails);
      // console.log(this.result.categoryDetails.subCategoryDetails.questionDetails.answerDetails);
      // this.a = this.result.answerDetails;
      // console.log(this.a);
     
    });
    
  //  this.userForm = this.formBuilder.group({
  
  //  });
  }

  next():void{
 

    this.router.navigate(['five']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['three']);
 
    
   }
  }
