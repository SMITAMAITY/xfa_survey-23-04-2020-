import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-six',
  templateUrl: './six.component.html',
  styleUrls: ['./six.component.css']
})
export class SixComponent implements OnInit {

  url:string= "http://localhost:8080/QuestionDetails/SecureConnectivity";
  userForm: FormGroup;

  a:any;
  c:any;
  i:any;
  j:any;
  k:any;
  a1:any;
  a2:any;
  a3:any;
  a4:any;
  a5:any;
  
  z1:any;
  z2:any;
  z3:any;
  z4:any;
  z5:any;
  z6:any;
    result:any;
  
    constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }
  
    ngOnInit() {
      this.http.get(this.url).subscribe(data=>{
        
        
        this.result = data;
        console.log(this.result);

            this.a1 = this.result[0].subCategoryDetails[0];
         
            this.a2= this.result[0].subCategoryDetails[1];
            this.a3= this.result[0].subCategoryDetails[2];
        

       
      });

    }
  

  next():void{
 

    this.router.navigate(['seven']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['five']);
 
    
   }
  }
