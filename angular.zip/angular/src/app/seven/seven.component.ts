import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-seven',
  templateUrl: './seven.component.html',
  styleUrls: ['./seven.component.css']
})
export class SevenComponent implements OnInit {

  a:any;
  url:string= "http://localhost:8080/QuestionDetails";
  userForm: FormGroup;
  
  result:any;
  
  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.http.get(this.url).subscribe(data=>{
      this.result=data;
       console.log(this.result);
      console.log(this.result.questionDetailsId);
      this.a = this.result.answerDetails;
      console.log(this.a);
      console.log(this.a[1].answerId);
    });
   }
   
   
   next():void{
   
   
    this.router.navigate(['seven']);
   
   
   }
   
   
   prev():void{
   
   
   
     this.router.navigate(['six']);
   
    
   }
   }
   