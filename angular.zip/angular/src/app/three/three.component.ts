import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl} from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-three',
  templateUrl: './three.component.html',
  styleUrls: ['./three.component.css']
})
export class ThreeComponent implements OnInit {

  url:string= "http://localhost:8080/QuestionDetails/EndUserDevice";
  userForm: FormGroup;
a:any;
c:any;
i:any;
j:any;
k:any;
a1:any;
a2:any;
a3:any;
a4:any;
a5:any;

z1:any;
z2:any;
z3:any;
z4:any;
z5:any;
z6:any;
  result:any;

  constructor(private http:HttpClient,private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.http.get(this.url).subscribe(data=>{
      
      
      this.result = data;
      console.log(this.result);
      
      this.result=data;
      console.log(this.result);
      // this.a = this.result[0].subCategoryDetails[0];
     // this.c = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z1 = this.result[0].subCategoryDetails[0].questionDetails[0];
      this.z2 = this.result[0].subCategoryDetails[1].questionDetails[0];
      this.z6 = this.result[0].subCategoryDetails[1].questionDetails[1];
      this.z3= this.result[0].subCategoryDetails[2].questionDetails[0];
      this.z4= this.result[0].subCategoryDetails[3].questionDetails[0];
      this.z5= this.result[0].subCategoryDetails[4].questionDetails[0];
    

        // for(this.j=0;this.j<5;this.j++)
        // {
        //   this.a = this.result[0].subCategoryDetails[this.j];
        // }
        

        // for(let i=0;i<5;i++)
        // {
          this.a1 = this.result[0].subCategoryDetails[0];
          this.a2= this.result[0].subCategoryDetails[1];
          this.a3= this.result[0].subCategoryDetails[2];
          this.a4= this.result[0].subCategoryDetails[3];
          this.a5= this.result[0].subCategoryDetails[4];
    
        // }
   
      console.log(this.a);
      // console.log(this.result.CategoryDetails.SubCategoryDetails);
      // console.log(this.result.categoryDetails.subCategoryDetails.questionDetails);
      // console.log(this.result.categoryDetails.subCategoryDetails.questionDetails.answerDetails);
      // this.a = this.result.answerDetails;
      // console.log(this.a);
     
    });
    
  //  this.userForm = this.formBuilder.group({
  
  //  });
  }

  next():void{
 

    this.router.navigate(['four']);

  
  }

  
  prev():void{
 
  
 
     this.router.navigate(['two']);
 
    
   }
  }
